from setuptools import setup

setup(
 name="caculosbasicosmatematicos",
version="1.0",
description="Calucladora de suma, resta, multiplicacion, potencia y redondeo",
author="Jesus Aguirre Bastidas",
author_email="99jesus.aguirre@gmail.com",
url="",
packages=["moduloMatematico", "modulomatematico.calculosBasicos"]
)